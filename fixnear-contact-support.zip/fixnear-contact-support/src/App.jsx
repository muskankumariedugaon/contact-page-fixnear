
import React, { useState } from "react";
import {
  ArrowLeft, ChevronDown, Upload, MessageCircle, ShieldCheck,
  ArrowRight, CheckCircle, Paperclip, Menu, X,
} from "lucide-react";

export default function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [file, setFile] = useState(null);
  const [submitted, setSubmitted] = useState(false);

  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    supportType: "General inquiry",
    request: "",
    subject: "",
    message: "",
  });

  const handleChange = (e) =>
    setFormData({ ...formData, [e.target.name]: e.target.value });

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
    console.log("Support Request:", formData);
    console.log("Attachment:", file);
  };

  const navLinks = ["Home", "Services", "How It Works", "About", "FixNear?"];

  const footerLinks = [
    { title: "Services", links: ["Electrician", "Plumber", "AC Repair", "Carpenter", "Painter"] },
    { title: "Company", links: ["About", "How It Works", "Become a Technician", "Contact"] },
    { title: "Support", links: ["Help Center", "Privacy", "Terms", "Safety"] },
  ];

  return (
    <div className="min-h-screen bg-[#F7F2E9] text-[#204B3B] font-sans">

      {/* NAVBAR */}
      <header className="sticky top-0 z-50 bg-[#F7F2E9]/95 backdrop-blur-md border-b border-[#E8DFCF]">
        <div className="max-w-[1240px] mx-auto px-5 md:px-8 h-[84px] flex items-center justify-between">

          <a href="#" className="flex items-center shrink-0">
            <img
              src="/fixnear-logo.png"
              alt="FixNear Logo"
              className="w-[145px] h-[68px] sm:w-[160px] sm:h-[74px] object-contain"
            />
          </a>

          <nav className="hidden lg:flex items-center gap-8">
            {navLinks.map((link) => (
              <a
                key={link}
                href="#"
                className="text-[14px] font-semibold text-[#47675A] hover:text-[#D15F3B] transition"
              >
                {link}
              </a>
            ))}
          </nav>

          <div className="hidden lg:flex items-center gap-5">
            <a href="#" className="text-[14px] font-semibold hover:text-[#D15F3B]">
              Become Tech
            </a>
            <a href="#" className="text-[14px] font-semibold hover:text-[#D15F3B]">
              Login
            </a>
            <a
              href="#"
              className="bg-[#204B3B] text-white px-5 py-3 rounded-lg text-[13px] font-bold hover:bg-[#16392D] transition"
            >
              Sign Up
            </a>
          </div>

          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className="lg:hidden p-2 rounded-lg hover:bg-[#E8DFCF]"
            aria-label="Toggle menu"
          >
            {menuOpen ? <X size={25} /> : <Menu size={25} />}
          </button>
        </div>

        {menuOpen && (
          <div className="lg:hidden bg-[#F7F2E9] border-t border-[#E8DFCF] px-6 py-5 space-y-4">
            {navLinks.map((link) => (
              <a
                href="#"
                key={link}
                onClick={() => setMenuOpen(false)}
                className="block text-base font-semibold"
              >
                {link}
              </a>
            ))}

            <div className="flex gap-5 pt-3 border-t border-[#E8DFCF]">
              <a href="#" className="text-base font-semibold">Login</a>
              <a href="#" className="text-base font-semibold">Become Tech</a>
            </div>

            <a
              href="#"
              className="inline-block bg-[#204B3B] text-white px-6 py-3 rounded-lg text-base"
            >
              Sign Up
            </a>
          </div>
        )}
      </header>

      {/* HERO SECTION */}
      <section className="border-b border-[#E8DFCF]">
        <div className="max-w-[1240px] mx-auto px-5 md:px-8 pt-8 pb-12">

          <a
            href="#"
            className="inline-flex items-center gap-2 text-[14px] font-semibold text-[#426452] hover:text-[#D15F3B]"
          >
            <ArrowLeft size={17} />
            Back to Help Center
          </a>

          <div className="text-center pt-10 pb-1">
            <span className="inline-flex items-center gap-2 bg-[#E5D5BC] text-[#49624E] px-4 py-2 rounded-full text-[11px] font-bold tracking-wider">
              <span className="w-2 h-2 rounded-full bg-[#D15F3B]" />
              FIXNEAR HELP CENTER
            </span>

            <h1 className="text-[38px] md:text-[46px] font-extrabold mt-5 tracking-tight text-[#204B3B]">
              Contact Support
            </h1>

            <p className="text-[15px] md:text-[16px] text-[#718074] mt-3 leading-7">
              Tell us what you're dealing with and we'll get you back.
              <br className="hidden sm:block" />
              We're here to find a faster way to fix it.
            </p>
          </div>
        </div>
      </section>

      {/* MAIN CONTENT */}
      <main className="max-w-[1240px] mx-auto px-5 md:px-8 py-10 md:py-12">
        <div className="grid grid-cols-1 lg:grid-cols-[1.85fr_0.95fr] gap-7 lg:gap-10 items-start">

          {/* CONTACT FORM */}
          <section className="border border-[#E6D9C6] rounded-xl p-5 sm:p-7 md:p-8">
            <div className="mb-7">
              <h2 className="text-[25px] font-bold text-[#204B3B]">
                How can we help?
              </h2>
              <p className="text-[14px] text-[#7D897D] mt-2">
                <span className="text-[#D15F3B]">*</span> Required fields. Everything is safe and secure.
              </p>
            </div>

            {submitted ? (
              <div className="py-14 text-center">
                <CheckCircle size={56} className="mx-auto text-[#204B3B]" />

                <h3 className="text-2xl font-bold mt-5">
                  Request Submitted!
                </h3>

                <p className="text-base text-[#788579] mt-3 leading-7">
                  Thank you for contacting FixNear. Our support team will get back to you soon.
                </p>

                <button
                  onClick={() => setSubmitted(false)}
                  className="mt-6 bg-[#204B3B] text-white px-6 py-3 rounded-lg text-base font-semibold"
                >
                  Send Another Message
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[14px] font-bold mb-2">
                      Full name <span className="text-[#D15F3B]">*</span>
                    </label>

                    <input
                      type="text"
                      name="fullName"
                      value={formData.fullName}
                      onChange={handleChange}
                      placeholder="Your full name"
                      required
                      className="form-field text-base"
                    />
                  </div>

                  <div>
                    <label className="block text-[14px] font-bold mb-2">
                      Email address <span className="text-[#D15F3B]">*</span>
                    </label>

                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      placeholder="you@example.com"
                      required
                      className="form-field text-base"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[14px] font-bold mb-2">
                    Support type <span className="text-[#D15F3B]">*</span>
                  </label>

                  <div className="relative">
                    <select
                      name="supportType"
                      value={formData.supportType}
                      onChange={handleChange}
                      required
                      className="form-field appearance-none cursor-pointer text-base"
                    >
                      {[
                        "General inquiry",
                        "Booking issue",
                        "Payment issue",
                        "Technician related issue",
                        "Cancellation or refund",
                        "Account related issue",
                        "Other",
                      ].map((v) => (
                        <option key={v}>{v}</option>
                      ))}
                    </select>

                    <ChevronDown
                      size={18}
                      className="absolute right-3 top-3.5 pointer-events-none text-[#718074]"
                    />
                  </div>

                  <p className="hint text-[13px]">
                    Pricing, matching &amp; service details, and technical concerns. General questions are welcome!
                  </p>
                </div>

                <div>
                  <label className="block text-[14px] font-bold mb-2">
                    Booking reference (if relevant)
                  </label>

                  <input
                    type="text"
                    name="request"
                    value={formData.request}
                    onChange={handleChange}
                    placeholder="Add a reference if you have one"
                    className="form-field text-base"
                  />

                  <p className="hint text-[13px]">
                    Leave this blank if your question isn't about an existing request.
                  </p>
                </div>

                <div>
                  <label className="block text-[14px] font-bold mb-2">
                    Subject <span className="text-[#D15F3B]">*</span>
                  </label>

                  <input
                    type="text"
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    placeholder="A short summary of what you need help with"
                    required
                    className="form-field text-base"
                  />
                </div>

                <div>
                  <label className="block text-[14px] font-bold mb-2">
                    Message / precise description <span className="text-[#D15F3B]">*</span>
                  </label>

                  <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    required
                    rows={5}
                    placeholder="Tell us what happened and share your thoughts..."
                    className="form-field text-base resize-y py-3"
                  />

                  <p className="hint text-[13px]">
                    Include what you're trying to fix, any steps you tried, and anything that might help us provide help.
                  </p>
                </div>

                <div>
                  <label className="block text-[14px] font-bold mb-2">
                    Attachment (optional)
                  </label>

                  <label className="flex items-center gap-4 p-4 rounded-lg border border-dashed border-[#DCCEB9] bg-[#F9F6EF] cursor-pointer hover:border-[#204B3B] transition">
                    <div className="w-12 h-12 flex items-center justify-center rounded-lg bg-[#E8DFCF] shrink-0">
                      <Upload size={21} />
                    </div>

                    <div className="flex-1 min-w-0">
                      <p className="text-[14px] font-bold">
                        Choose a file or drag it here
                      </p>

                      <p className="text-[13px] text-[#879185] mt-1">
                        A screenshot or photo can help us understand the issue.
                      </p>

                      {file && (
                        <p className="text-[13px] text-[#204B3B] mt-2 font-semibold truncate">
                          <Paperclip size={14} className="inline mr-1" />
                          {file.name}
                        </p>
                      )}
                    </div>

                    <input
                      type="file"
                      accept="image/*,.pdf"
                      className="hidden"
                      onChange={(e) => setFile(e.target.files[0])}
                    />
                  </label>

                  <p className="hint text-[13px]">
                    Max size 5 MB. JPG, PNG, PDF files accepted.
                  </p>
                </div>

                <div className="pt-1 flex flex-wrap items-center gap-4">
                  <button
                    type="submit"
                    className="bg-[#204B3B] hover:bg-[#15392C] text-white px-7 py-3.5 rounded-lg text-[14px] font-bold transition-all shadow-sm"
                  >
                    Send message
                  </button>

                  <span className="text-[13px] text-[#849083]">
                    We care about solving your concern.
                  </span>
                </div>
              </form>
            )}
          </section>

          {/* RIGHT SIDEBAR */}
          <aside className="space-y-5">

            <div className="bg-[#E0CEB3] rounded-xl p-6 md:p-7">
              <MessageCircle size={26} className="text-[#557263] mb-5" />

              <p className="text-[12px] tracking-widest font-bold text-[#C66A46] uppercase mb-3">
                AI TIP &amp; GUIDANCE
              </p>

              <h3 className="text-[24px] font-extrabold leading-8 text-[#204B3B]">
                Let's make your next step clearer.
              </h3>

              <p className="text-[14px] text-[#667568] leading-6 mt-3">
                You don't need the perfect explanation. A few details about what happened are a great start.
              </p>

              <div className="space-y-5 mt-6">
                <div>
                  <h4 className="text-[15px] font-bold">
                    Tell us what you tried
                  </h4>
                  <p className="text-[13px] text-[#687669] leading-6 mt-1">
                    Did you make a booking? Is a technician already assigned? This helps us get started.
                  </p>
                </div>

                <div>
                  <h4 className="text-[15px] font-bold">
                    Share the real details
                  </h4>
                  <p className="text-[13px] text-[#687669] leading-6 mt-1">
                    A short description, a screenshot or a booking reference can make all the difference.
                  </p>
                </div>

                <div>
                  <h4 className="text-[15px] font-bold">
                    Add context, if you like
                  </h4>
                  <p className="text-[13px] text-[#687669] leading-6 mt-1">
                    A little extra information helps us understand your issue and find a better solution.
                  </p>
                </div>
              </div>
            </div>

            <div className="border border-[#E6D9C6] bg-[#FBF8F2] rounded-xl p-5">
              <div className="flex items-center gap-2 mb-3">
                <ShieldCheck size={22} className="text-[#D15F3B]" />
                <h3 className="text-[16px] font-bold">
                  Keep private details private
                </h3>
              </div>

              <p className="text-[13px] text-[#758174] leading-6">
                Please don't share sensitive OTPs, passwords, full payment details, or unnecessary personal information. We'll only ask for what we need to help you.
              </p>

              <p className="text-[13px] text-[#758174] leading-6 mt-3">
                Our team follows secure communication practices. Your information is handled with care and respect.
              </p>
            </div>

            <div className="px-1 py-2">
              <h3 className="text-[20px] font-extrabold">
                Looking for a quick answer?
              </h3>

              <p className="text-[14px] text-[#7B887C] leading-6 mt-2">
                Browse popular answers on our Help Center, your account and booking are in one place.
              </p>

              <a
                href="#"
                className="inline-flex items-center gap-2 text-[14px] font-bold mt-4 hover:text-[#D15F3B] transition"
              >
                Explore Help Hub
                <ArrowRight size={17} />
              </a>
            </div>
          </aside>
        </div>
      </main>

      {/* FOOTER */}
      <footer className="max-w-[1240px] mx-auto px-5 md:px-8 pt-12 pb-5">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 pb-10">

          <div>
            <h2 className="text-[23px] font-extrabold tracking-tight">
              FixNear
            </h2>

            <p className="text-[13px] text-[#7C897D] leading-6 mt-3 max-w-[180px]">
              FIX IT FAST. FIX IT RIGHT.
              <br />
              Your trusted home service partner.
            </p>
          </div>

          {footerLinks.map((item) => (
            <div key={item.title}>
              <h3 className="text-[15px] font-extrabold mb-4">
                {item.title}
              </h3>

              <ul className="space-y-3">
                {item.links.map((link) => (
                  <li key={link}>
                    <a
                      href="#"
                      className="text-[13px] text-[#788579] hover:text-[#D15F3B] transition"
                    >
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="border-t border-[#E6D9C6] pt-5 text-center">
          <p className="text-[13px] text-[#879184]">
            © 2026 FixNear. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}
